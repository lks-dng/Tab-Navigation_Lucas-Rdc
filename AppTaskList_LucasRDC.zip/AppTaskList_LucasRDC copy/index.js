import App from './src/index';
import { registerRootComponent } from "expo";

registerRootComponent(App);
