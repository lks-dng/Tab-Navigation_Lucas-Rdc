//import AddItem from './components/add-item';
import { AddItem, CustomModal, TaskList } from './components';
import React, { useState } from 'react';

import { View } from 'react-native';
import { colors } from './constants /colors';
import { styles } from './styles';

const App = () =>  {
  const [task, setTask] = useState('');
  const [tasks, setTasks] = useState([]);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);

  const onHandlerChange = (text) => {
    setTask(text)
  }

  const onHandlerSubmit = () => {
    setTasks([
      ... tasks,
      {
        id: Math.random().toString(), 
        value: task,
      }
    ]);
    setTask('');
  }

  const onHandlerModal = (item) => {
    setIsModalVisible(!isModalVisible); 
    setSelectedTask(item);
  }

  const onHandleCancel = () => {
    setIsModalVisible(!isModalVisible);
    setSelectedTask(null);
  }


  const onHandleDelete = (id) => {
    setTasks((prevTaskList) => prevTaskList.filter((task) => task.id !== selectedTask.id))
    setIsModalVisible(!isModalVisible);

  }

  return (
    <View style={styles.container}>
      <AddItem
        buttonColor={colors.appleGreen}
        buttonText='Add'
        onHandlerChange={onHandlerChange}
        onHandlerSubmit={onHandlerSubmit}
        placeholder='Add a New Task'
        task={task}
      />
      
      <TaskList
        tasks={tasks}
        onHandlerModal={onHandlerModal}
      />

      <CustomModal
        isModalVisible={isModalVisible}
        onHandleCancel={onHandleCancel}
        onHandleDelete={onHandleDelete}
        selectedTask={selectedTask}
      />
    </View>
  );
}

// #0a234e Azul Oscuro
// #12326a Azul Claro
// #ffffff Blanco
// #f1a2a6 Rosa Claro
// #bed7a4 Verde Manzana
// #f6c797 Color Crema

export default App;