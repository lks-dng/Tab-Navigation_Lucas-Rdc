import { FlatList } from "react-native"
import React from "react"
import TaskItem from "./item"
import { styles } from "./styles";

const TaskList = ({ tasks, onHandlerModal}) => {
    
    const renderItem = ({ item }) => (
        <TaskItem
            item={item}
            onHandlerModal={onHandlerModal}
        />
    )
    
    const keyEstractor = (item) => item.id;

    return (
        <FlatList
            data={tasks}
            renderItem={renderItem}
            keyEstractor={keyEstractor}
            style={styles.listContainer}
            showsVerticalScrollIndicator={false}
        />
    )
}

export default TaskList;


