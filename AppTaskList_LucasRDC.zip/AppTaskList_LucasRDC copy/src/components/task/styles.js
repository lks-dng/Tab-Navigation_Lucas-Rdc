import { StyleSheet } from "react-native"

export const styles = StyleSheet.create({
    listContainer: {
        marginHorizontal: 20,
        marginTop: 15,
    }
})