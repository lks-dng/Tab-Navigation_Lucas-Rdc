import { StyleSheet } from "react-native"

export const styles = StyleSheet.create({
    itemList: {
        width: '85%',
        paddingTop: 10,
        paddingLeft: 10,
        paddingRight: 10,
        borderColor: '#bed7a4',
        borderWidth: 1.5,
        height: 40,
        color: '#bed7a4',
        fontSize: 14,
        fontFamily: 'Menlo',  
        fontWeight: 'bold',
        marginBottom: 10
    
      },

      itemContainer: {
        flexDirection: "row",
        justifyContent: 'space-between',
        alignItems: 'center',
        // paddingVertical: 20,
        // paddingHorizontal: 10,
      }
})