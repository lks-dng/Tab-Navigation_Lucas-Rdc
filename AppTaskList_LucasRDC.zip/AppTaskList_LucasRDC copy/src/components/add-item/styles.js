import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({ 
  inputContainer: {
    marginTop: 63,
    marginHorizontal: 20,
    flexDirection: 'row',
    fontFamily: 'Menlo',
    justifyContent: 'space-between'
  },

  input: {
    width: '85%',
    paddingLeft: 10,
    paddingRight: 10,
    borderColor: '#ffffff',
    borderWidth: 1.5,
    height: 40, 
    color: '#ffffff',
    fontFamily: 'Menlo', 
    marginRight: 10
  },
  button: {
    color: '#bed7a4',
    fontWeight: 'bold',
    borderColor: '#bed7a4',
    borderWidth: 1.5,
    paddingHorizontal: 10,
    paddingVertical: 10,
  }
})