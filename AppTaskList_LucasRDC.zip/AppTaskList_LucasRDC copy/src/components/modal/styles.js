import { StyleSheet } from "react-native";

export const styles = StyleSheet.create ({
    modaleContainer: {
        backgroundColor: '#0a234e',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 50,
        paddingVertical: 20,
      },
      modalTitle: {
        fontFamily: 'Menlo',
        fontSize: 14,
        fontWeight: 'bold',
        marginBottom: 10,
        color: '#ffffff'
      },
      ModalDetailContainer: {
        paddingVertical: 20,
      },
      modalDetailMessage: {
        fontFamily: 'Menlo',
        fontSize: 16,
        color: '#bed7a4'
    
      },
      selectedTask: {
        fontSize: 12,
        fontFamily: 'Menlo',
        color: '#bed7a4',
        fontWeight: 'bold',
        paddingVertical: 10,
        textAlign: 'center',
      },
      modalButtonContainer: {
        width: '75%',
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginHorizontal: 20,
      },
})