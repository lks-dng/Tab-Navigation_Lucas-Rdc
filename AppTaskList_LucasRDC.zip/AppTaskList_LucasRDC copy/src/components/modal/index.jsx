import { Button, Modal, Text, View } from "react-native";

import React from "react";
import { styles } from "./styles";

const CustomModal = ({isModalVisible, selectedTask, onHandleCancel, onHandleDelete}) => {
    return (
        <Modal visible={isModalVisible} animationType='slide'>
        <View style={styles.modaleContainer}>
            <Text style={styles.modalTitle}>Task Detail</Text>
            <View style={styles.ModalDetailContainer}>
                <Text style={styles.modalDetailMessage}>Are you sure to delete this task?</Text>
                <Text style={styles.selectedTask}>{selectedTask?.value}</Text>
            </View>
            <View style={styles.modalButtonContainer}>
                <Button
                    title='Back'
                    color='#bed7a4'
                    onPress={onHandleCancel}
                />
                <Button
                    title='Delete'
                    color='#f1a2a6'
                    onPress={onHandleDelete}
                />
            </View>
        </View>
        </Modal>
    )
}

export default CustomModal;