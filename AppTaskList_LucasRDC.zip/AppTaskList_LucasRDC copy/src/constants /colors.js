export const colors = {
    background:'#0a234e', //Azul Oscuro
    backgroundAlt:'#12326a', //Azul Claro
    white:'#ffffff', //Blanco
    rose:'#f1a2a6', //Rosa Claro
    appleGreen:'#bed7a4', //Verde Manzana
    cream:'#f6c797', //Color Crema
}