import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    
    container: {
      flex: 1,
      backgroundColor: '#0a234e',
      
    },
  });
  
  // #0a234e Azul Oscuro
  // #12326a Azul Claro
  // #ffffff Blanco
  // #f1a2a6 Rosa Claro
  // #bed7a4 Verde Manzana
  // #f6c797 Color Crema
  
